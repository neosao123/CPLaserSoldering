const strings = {
    API_ROUTE: "https://neotesting.online/cplasersoldering/testing/api",
  };
  export default strings;
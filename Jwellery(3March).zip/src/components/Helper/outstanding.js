import { axiosPrivate } from "./axios";
export const OutstandingList = async (userId, offset, customerId,paid) => {
    let res = await axiosPrivate.get("/customer/bill/list?userId=" + userId + "&offset=" + offset + "&customerId=" + customerId +"&type=" + paid);
    return res.data;
};
